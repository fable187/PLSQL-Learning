create or replace type ut_expectations_reporter under ut_documentation_reporter(
  /*
  utPLSQL - Version 3
  Copyright 2016 - 2020 utPLSQL Project

  Licensed under the Apache License, Version 2.0 (the "License"):
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
  */
  report_all_expectations varchar2(1),


  constructor function ut_expectations_reporter(a_report_all_expectations varchar2 := 'Y') return self as result,

  overriding member procedure after_calling_test(a_test ut_test),
  overriding member procedure after_calling_run(a_run in ut_run),

  overriding member function get_description return varchar2

)
not final
/
