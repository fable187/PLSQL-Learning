create or replace type body ut_documentation_reporter is
  /*
  utPLSQL - Version 3
  Copyright 2016 - 2021 utPLSQL Project

  Licensed under the Apache License, Version 2.0 (the "License"):
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
  */

  constructor function ut_documentation_reporter(self in out nocopy ut_documentation_reporter) return self as result is
  begin
    self.init($$plsql_unit);
    self.lvl                       := 0;
    self.failed_test_running_count := 0;
    return;
  end;

  member function tab(self in ut_documentation_reporter) return varchar2 is
  begin
    return rpad(' ', self.lvl * 2);
  end tab;

  overriding member procedure print_clob(self in out nocopy ut_documentation_reporter, a_clob clob, a_item_type varchar2 := null) is
    l_lines     ut_varchar2_list;
    l_out_lines ut_varchar2_rows := ut_varchar2_rows();
  begin
    if a_clob is not null and dbms_lob.getlength(a_clob) > 0 then
      l_lines := ut_utils.clob_to_table(a_clob, ut_utils.gc_max_storage_varchar2_len - length(nvl(tab(),0)));
      for i in 1 .. l_lines.count loop
        if l_lines(i) is not null then
          ut_utils.append_to_list(l_out_lines, tab() || l_lines(i) );
        end if;
      end loop;
      (self as ut_output_reporter_base).print_text_lines(l_out_lines, a_item_type);
    end if;
  end;

  overriding member procedure print_text(self in out nocopy ut_documentation_reporter, a_text varchar2, a_item_type varchar2 := null) is
    l_lines ut_varchar2_list;
  begin
    if a_text is not null then
      l_lines := ut_utils.string_to_table(a_text);
      for i in 1 .. l_lines.count loop
        (self as ut_output_reporter_base).print_text(tab || l_lines(i), a_item_type);
      end loop;
    end if;
  end;

  overriding member procedure before_calling_suite(self in out nocopy ut_documentation_reporter, a_suite ut_logical_suite) as
  begin
    self.print_text(coalesce(a_suite.description, a_suite.name));
    lvl := lvl + 1;
  end;

  overriding member procedure after_calling_test(self in out nocopy ut_documentation_reporter, a_test ut_test) as
    l_message varchar2(4000);

  begin
    l_message := coalesce(a_test.description, a_test.name)||' ['||round(a_test.execution_time,3)||' sec]';
    --if test failed, then add it to the failures list, print failure with number
    if a_test.result = ut_utils.gc_disabled then
      self.print_yellow_text(l_message || ' (DISABLED'|| 
                                             case when a_test.disabled_reason is not null 
                                               then ' - '||a_test.disabled_reason 
                                               else null 
                                             end || ')');
    elsif a_test.result = ut_utils.gc_success then
      self.print_green_text(l_message);
    elsif a_test.result > ut_utils.gc_success then
      failed_test_running_count := failed_test_running_count + 1;
      self.print_red_text(l_message || ' (FAILED - ' || failed_test_running_count || ')');
    end if;

    -- reproduce the output from before/after procedures and the test
    self.print_clob(a_test.get_serveroutputs);
  end;

  overriding member procedure after_calling_before_all(self in out nocopy ut_documentation_reporter, a_executable in ut_executable) is
  begin
    if a_executable.serveroutput is not null and a_executable.serveroutput != empty_clob() then
      self.print_clob(a_executable.serveroutput);
    end if;
  end;

  overriding member procedure after_calling_after_all(self in out nocopy ut_documentation_reporter, a_executable in ut_executable) is
  begin
    if a_executable.serveroutput is not null and a_executable.serveroutput != empty_clob() then
      self.print_clob(a_executable.serveroutput);
    end if;
  end;

  overriding member procedure after_calling_suite(self in out nocopy ut_documentation_reporter, a_suite ut_logical_suite) as
  begin
    lvl := lvl - 1;
    if lvl = 0 then
      self.print_text(' ');
    end if;
  end;

  overriding member procedure after_calling_run(self in out nocopy ut_documentation_reporter, a_run in ut_run) as
    l_summary_text   varchar2(4000);
    l_warning_index pls_integer := 0;
    -- make all warning indexes uniformly indented
    c_warnings_lpad constant integer := length(to_char(a_run.results_count.warnings_count));

    procedure print_failure_for_expectation(a_expectation ut_expectation_result) is
      l_lines ut_varchar2_list;
    begin
      l_lines := a_expectation.get_result_lines();
      for i in 1 .. l_lines.count loop
        self.print_red_text(l_lines(i));
      end loop;
      self.print_cyan_text(a_expectation.caller_info);
      self.print_text(' ');
    end;

    procedure print_failures_for_test(a_test ut_test, a_failure_no in out nocopy integer) is
    begin
      if a_test.result > ut_utils.gc_success then
        a_failure_no := a_failure_no + 1;
        self.print_text(lpad(a_failure_no, length(failed_test_running_count) + 2, ' ') || ') ' ||
                        nvl(a_test.name, a_test.item.form_name));
        self.lvl := self.lvl + 3;

        self.print_red_text(ut_utils.table_to_clob(a_test.get_error_stack_traces()));

        for j in 1 .. a_test.failed_expectations.count loop
          print_failure_for_expectation(a_test.failed_expectations(j));
        end loop;

        self.lvl := self.lvl - 3;
      end if;
    end;

    procedure print_failures_from_suite(a_suite ut_logical_suite, a_failure_no in out nocopy integer) is
    begin
      for i in 1 .. a_suite.items.count loop
        if a_suite.items(i) is of(ut_logical_suite) then
          print_failures_from_suite(treat(a_suite.items(i) as ut_logical_suite), a_failure_no);
        elsif a_suite.items(i) is of(ut_test) then
          print_failures_for_test(treat(a_suite.items(i) as ut_test), a_failure_no);
        end if;
      end loop;
    end;

    procedure print_failures_details(a_run in ut_run) is
      l_failure_no integer := 0;
    begin
      if a_run.results_count.failure_count > 0 or a_run.results_count.errored_count > 0 then

        self.print_text('Failures:');
        self.print_text(' ');
        for i in 1 .. a_run.items.count loop
          print_failures_from_suite(treat(a_run.items(i) as ut_logical_suite), l_failure_no);
        end loop;
      end if;
    end;

    procedure print_item_warnings(a_item in ut_suite_item) is
      l_items ut_suite_items;
    begin
      if a_item is of (ut_logical_suite) then
        l_items := treat(a_item as ut_logical_suite).items;
        for i in 1 .. l_items.count loop
          print_item_warnings(l_items(i));
        end loop;
      end if;

      if a_item.warnings is not null and a_item.warnings.count > 0 then
        for i in 1 .. a_item.warnings.count loop
          l_warning_index := l_warning_index + 1;
          self.print_text('  ' || lpad(l_warning_index, c_warnings_lpad) || ') ' || a_item.path);
          self.lvl := self.lvl + 3;
          self.print_red_text(a_item.warnings(i));
          self.lvl := self.lvl - 3;
        end loop;
        self.print_text(' ');
      end if;
    end;

    procedure print_warnings(a_run in ut_run) is
    begin
      if a_run.results_count.warnings_count > 0 then
        self.print_text(' ');
        self.print_text('Warnings:');
        self.print_text(' ');
        for i in 1 .. a_run.items.count loop
          print_item_warnings(treat(a_run.items(i) as ut_suite_item));
        end loop;
      end if;
    end;

  begin
    print_failures_details(a_run);
    print_warnings(a_run);
    self.print_text('Finished in ' || ut_utils.interval_to_text(numtodsinterval(a_run.execution_time,'second')) );

    l_summary_text :=
      a_run.results_count.total_count || ' tests, '
      || a_run.results_count.failure_count || ' failed, ' || a_run.results_count.errored_count || ' errored, '
      || a_run.results_count.disabled_count ||' disabled, ' || a_run.results_count.warnings_count || ' warning(s)';
    if a_run.results_count.failure_count + a_run.results_count.errored_count + a_run.results_count.warnings_count > 0 then
      self.print_red_text(l_summary_text);
    else
      self.print_green_text(l_summary_text);
    end if;
    if a_run.random_test_order_seed is not null then
      self.print_text('Tests were executed with random order seed '''||a_run.random_test_order_seed||'''.');
    end if;
    self.print_text(' ');
    (self as ut_reporter_base).after_calling_run(a_run);
  end;

  overriding member function get_description return varchar2 as
  begin
    return 'A textual pretty-print of unit test results (usually use for console output)';
  end;

end;
/
